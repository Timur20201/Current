import 'package:flutter/material.dart';
// import 'package:flutter_map/flutter_map.dart'; // Для Mapbox або іншої бібліотеки карт
// import 'package:latlong2/latlong.dart'; // Для LatLng

class EventMap extends StatelessWidget {
  final List<dynamic> events;

  const EventMap({super.key, required this.events});

  @override
  Widget build(BuildContext context) {
    // Приклад використання акцентних кольорів з теми
    // final categoryColors = Theme.of(context).extension<_CategoryColors>()!;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Map Placeholder (Mapbox/Google Maps integration here)',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, color: Colors.white70),
          ),
          const SizedBox(height: 20),
          // TODO: Інтегрувати Mapbox або Google Maps тут
          // Приклад відображення маркерів (без реальної карти)
          ...events.map((event) {
            Color markerColor;
            switch (event['category']) {
              case 'Conflict':
                markerColor = Colors.red[700]!;
                break;
              case 'Ecology':
                markerColor = Colors.green[700]!;
                break;
              case 'Natural Disaster':
                markerColor = Colors.orange[700]!;
                break;
              case 'Political':
                markerColor = Colors.blue[700]!;
                break;
              default:
                markerColor = Colors.grey;
            }
            return Padding(
              padding: const EdgeInsets.all(4.0),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.location_on, color: markerColor),
                  Text(
                    '${event['title']} (${event['category']})',
                    style: TextStyle(color: markerColor),
                  ),
                ],
              ),
            );
          }).toList(),
        ],
      ),
    );
    /*
    // Приклад інтеграції flutter_map
    return FlutterMap(
      options: MapOptions(
        initialCenter: LatLng(0, 0),
        initialZoom: 2.0,
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.example.app',
        ),
        MarkerLayer(
          markers: events.map((event) {
            Color markerColor;
            switch (event['category']) {
              case 'Conflict':
                markerColor = categoryColors.conflict;
                break;
              case 'Ecology':
                markerColor = categoryColors.ecology;
                break;
              case 'Natural Disaster':
                markerColor = categoryColors.naturalDisaster;
                break;
              case 'Political':
                markerColor = categoryColors.political;
                break;
              default:
                markerColor = Colors.grey;
            }
            return Marker(
              point: LatLng(event['coordinates']['latitude'], event['coordinates']['longitude']),
              width: 80,
              height: 80,
              child: Icon(Icons.location_on, color: markerColor, size: 40),
            );
          }).toList(),
        ),
      ],
    );
    */
  }
}
