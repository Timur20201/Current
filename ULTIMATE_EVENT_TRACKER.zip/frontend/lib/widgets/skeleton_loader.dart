import 'package:flutter/material.dart';

class SkeletonLoader extends StatelessWidget {
  const SkeletonLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 5, // Кількість елементів-заповнювачів
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Card(
            color: Colors.grey[900], // Темний колір для заповнювача
            child: const Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Заповнювач для заголовка
                  _SkeletonBox(width: 200, height: 20),
                  SizedBox(height: 10),
                  // Заповнювач для опису
                  _SkeletonBox(width: double.infinity, height: 15),
                  SizedBox(height: 5),
                  _SkeletonBox(width: double.infinity, height: 15),
                  SizedBox(height: 5),
                  _SkeletonBox(width: 150, height: 15),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SkeletonBox extends StatelessWidget {
  final double width;
  final double height;

  const _SkeletonBox({required this.width, required this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: Colors.grey[800], // Світліший сірий для анімації
        borderRadius: BorderRadius.circular(4),
      ),
    );
  }
}
