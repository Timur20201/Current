import 'package:flutter/material.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Authentication')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Firebase Auth UI integration here'),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // TODO: Implement Google Sign-In
              },
              child: const Text('Sign in with Google'),
            ),
            ElevatedButton(
              onPressed: () {
                // TODO: Implement Email/Password Sign-In
              },
              child: const Text('Sign in with Email'),
            ),
          ],
        ),
      ),
    );
  }
}
