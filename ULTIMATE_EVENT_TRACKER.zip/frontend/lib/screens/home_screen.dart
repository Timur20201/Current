import 'package:flutter/material.dart';
import 'package:world_event_tracker/widgets/event_map.dart';
import 'package:world_event_tracker/widgets/skeleton_loader.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _isLoading = true;
  List<dynamic> _events = []; // Тут будуть завантажені події

  @override
  void initState() {
    super.initState();
    _loadEvents();
  }

  Future<void> _loadEvents() async {
    // Імітація завантаження даних
    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      _isLoading = false;
      // Приклад даних, в реальності будуть завантажуватися з API
      _events = [
        {
          "id": "event1",
          "title": "Conflict in Region A",
          "description": "Details about conflict in region A.",
          "coordinates": {"latitude": 48.8566, "longitude": 2.3522},
          "category": "Conflict",
          "timestamp": "2023-10-27T10:00:00Z",
          "source_url": "https://example.com/event1"
        },
        {
          "id": "event2",
          "title": "Forest Fire in National Park",
          "description": "Large forest fire reported.",
          "coordinates": {"latitude": 34.0522, "longitude": -118.2437},
          "category": "Ecology",
          "timestamp": "2023-10-26T15:30:00Z",
          "source_url": "https://example.com/event2"
        },
      ];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('World Event Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () {
              // TODO: Реалізувати фільтрацію подій
            },
          ),
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () {
              // TODO: Перехід до екрану авторизації/профілю
            },
          ),
        ],
      ),
      body: _isLoading
          ? const SkeletonLoader() // Відображення Skeleton Screen під час завантаження
          : EventMap(events: _events), // Відображення карти з подіями
    );
  }
}
