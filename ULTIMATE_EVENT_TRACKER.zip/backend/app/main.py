from fastapi import FastAPI, Depends, HTTPException
from redis import Redis
from typing import List, Optional
import json
import os
from pydantic import BaseModel, Field
from datetime import datetime
import uuid

# Ініціалізація FastAPI додатку
app = FastAPI(
    title="World Event Tracker API",
    description="OSINT-орієнтований API для відстеження світових подій",
    version="1.0.0"
)

# Налаштування Redis
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_DB = int(os.getenv("REDIS_DB", 0))

redis_client = Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB, decode_responses=True)

# Pydantic моделі для валідації даних
class Coordinates(BaseModel):
    latitude: float
    longitude: float

class EventBase(BaseModel):
    title: str
    description: str
    coordinates: Coordinates
    category: str
    source_url: Optional[str] = None

class EventCreate(EventBase):
    pass

class Event(EventBase):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# Залежність для отримання клієнта Redis
def get_redis_client():
    try:
        yield redis_client
    finally:
        pass

@app.get("/")
async def root():
    return {"message": "Welcome to World Event Tracker API"}

@app.get("/events", response_model=List[Event])
async def get_latest_events(redis: Redis = Depends(get_redis_client)):
    """
    Отримує список останніх подій з кешу Redis.
    Якщо кеш порожній, повертає порожній список.
    """
    cached_events = redis.get("latest_events")
    if cached_events:
        try:
            events_data = json.loads(cached_events)
            return events_data
        except json.JSONDecodeError:
            raise HTTPException(status_code=500, detail="Error decoding cached events")
    return []

@app.post("/events", response_model=Event)
async def create_event(event: EventCreate, redis: Redis = Depends(get_redis_client)):
    """
    Створює нову подію та оновлює кеш Redis.
    У реальному додатку тут також буде збереження в PostgreSQL/PostGIS.
    """
    new_event = Event(**event.dict())
    
    # Отримання поточних подій з кешу
    cached_events = redis.get("latest_events")
    events_list = json.loads(cached_events) if cached_events else []
    
    # Додавання нової події (обмежимо кеш, наприклад, останніми 50 подіями)
    events_list.insert(0, new_event.dict(exclude={'timestamp'}))
    # Для серіалізації datetime в JSON
    new_event_dict = new_event.dict()
    new_event_dict['timestamp'] = new_event.timestamp.isoformat()
    
    # Оновлення списку для кешування (з конвертацією datetime)
    events_to_cache = []
    for e in events_list:
        if isinstance(e.get('timestamp'), datetime):
            e['timestamp'] = e['timestamp'].isoformat()
        events_to_cache.append(e)
    
    # Додаємо нову подію до списку для кешу
    events_to_cache = [new_event_dict] + (json.loads(cached_events) if cached_events else [])
    events_to_cache = events_to_cache[:50] # Зберігаємо лише останні 50
    
    redis.set("latest_events", json.dumps(events_to_cache))
    
    return new_event

@app.delete("/events/cache")
async def clear_event_cache(redis: Redis = Depends(get_redis_client)):
    """
    Очищує кеш останніх подій у Redis.
    """
    redis.delete("latest_events")
    return {"message": "Event cache cleared"}

# Приклад ініціалізації бази даних (SQLAlchemy/PostGIS) - концептуально
"""
from sqlalchemy import Column, Integer, String, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from geoalchemy2 import Geometry

Base = declarative_base()

class EventModel(Base):
    __tablename__ = 'events'
    id = Column(String, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    coordinates = Column(Geometry('POINT', srid=4326))
    category = Column(String(50))
    timestamp = Column(DateTime, default=datetime.utcnow)
    source_url = Column(String(255))
"""
